======================= FR =======================

Vous trouverez ici les fichiers 3D au format stl
pour avoir tout le robot dont vous aurez besoin:
-62 mailles
-4 roues
-2 axes
-2 rondelles
-1 essieu arrière
-1 base

Pour assembler le robot, utilisez la photo comment bild

Pour assembler les mailles entre eux, utilisez du fil de plastique pour l'impression 3D de 1,75

======================= EN =======================

Here you will find the 3d files in stl format
to have the whole robot you will need:
-62 meshes
-4 wheels
-2 axes
-2 washers
-1 rear axle
-1 base

To assemble the robot use the photo how to bild

To assemble the meshes between them use plastic wire for 3D printing of 1.75 mm