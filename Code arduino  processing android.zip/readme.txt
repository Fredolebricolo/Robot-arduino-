================== FR ================== 

Voici les différents codes du robot

- code arduino

- code android pour votre téléphone 

- traitement de code! utilisez processing.py!
      étape pour contrôler le robot depuis un ordinateur
	- votre ordinateur doit avoir Bluetooth
	-connectez l'ordinateur au module bluetooth
	-attribuer le port com3 au module bluetooth

================== EN ================== 

Here are the different codes for the robot

- arduino code

- android code for your phone

- code processing! use processing.py !
     step to control the robot from a computer
	- your computer must have bluetooth
	-connect the computer to the bluetooth module
	-attribute the com3 port to the bluetooth module