Here are the different codes for the robot

- arduino code

- android code for your phone

- code processing! use processing.py !
     step to control the robot from a computer
	- your computer must have bluetooth
	-connect the computer to the bluetooth module
	-attribute the com3 port to the bluetooth module